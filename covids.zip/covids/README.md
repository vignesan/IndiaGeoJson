# covid19india

<p align="center">
<img src="https://lh3.googleusercontent.com/c1R9ua5XDaInXNNYEVKs5NzwQ36gYCXi1VJ5kLRxGcDYmyUSJM3dnkzqaPWP_CniaHQbQSr4yQqxmsoEGvGFrWFnBRAVjI4=s2560" width="50%">
</p>

<p align="center">
  View our <a href="https://bit.ly/patientdb">live patient database</a>.
 </p>

## Setup

```
npm i && npm start
```

## Maintainers

- [jeremyphilemon](https://github.com/jeremyphilemon)

## Contribution

If you're new to contributing to Open Source on Github, [this guide](https://guides.github.com/activities/contributing-to-open-source/) can help you get started. Please check out the contribution guide for more details on how issues and pull requests work..
